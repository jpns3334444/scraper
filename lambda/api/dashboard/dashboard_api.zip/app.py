import json
import logging
import os
from decimal import Decimal
from datetime import datetime
import boto3
from boto3.dynamodb.conditions import Key, Attr
import re

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('DYNAMODB_TABLE', 'tokyo-real-estate-ai-RealEstateAnalysis')
table = dynamodb.Table(table_name)

# S3 configuration for image URLs
s3_bucket = os.environ.get('OUTPUT_BUCKET', 'tokyo-real-estate-ai-data')
s3_region = os.environ.get('AWS_REGION', 'ap-northeast-1')
s3_client = boto3.client('s3')

# CORS headers for browser access
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-User-Id',
    'Access-Control-Allow-Methods': 'GET,OPTIONS'
}

def decimal_to_float(obj):
    """Convert DynamoDB Decimal objects to Python float for JSON serialization"""
    if isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [decimal_to_float(v) for v in obj]
    return obj

def generate_image_urls(property_item):
    """Generate S3 presigned URLs for a property"""
    image_urls = []
    
    # Get property ID and analysis date
    property_id = property_item.get('property_id', '')
    analysis_date = property_item.get('analysis_date', '')
    photo_filenames = property_item.get('photo_filenames', '')
    
    if not property_id or not analysis_date:
        return image_urls
    
    # Extract date from analysis_date (format: 2025-01-25T10:30:00Z -> 2025-01-25)
    try:
        if 'T' in analysis_date:
            date_part = analysis_date.split('T')[0]
        else:
            date_part = analysis_date[:10]  # Take first 10 chars (YYYY-MM-DD)
    except:
        return image_urls
    
    # If we have photo_filenames, use those
    if photo_filenames:
        filenames = photo_filenames.split('|')
        for filename in filenames:
            if filename.strip():
                try:
                    # Generate presigned URL (valid for 1 hour)
                    presigned_url = s3_client.generate_presigned_url(
                        'get_object',
                        Params={'Bucket': s3_bucket, 'Key': filename.strip()},
                        ExpiresIn=3600
                    )
                    image_urls.append(presigned_url)
                except Exception as e:
                    logger.warning(f"Failed to generate presigned URL for {filename}: {e}")
                    continue
    else:
        # Fallback: try to generate URLs based on expected pattern
        # Pattern: raw/{date}/images/{property_id}_{index}.jpg
        for i in range(3):  # Try first 3 images
            s3_key = f"raw/{date_part}/images/{property_id}_{i}.jpg"
            try:
                # Check if object exists first
                s3_client.head_object(Bucket=s3_bucket, Key=s3_key)
                # Generate presigned URL (valid for 1 hour)
                presigned_url = s3_client.generate_presigned_url(
                    'get_object',
                    Params={'Bucket': s3_bucket, 'Key': s3_key},
                    ExpiresIn=3600
                )
                image_urls.append(presigned_url)
            except Exception as e:
                # Object doesn't exist or other error, skip
                continue
    
    return image_urls

def build_filter_expression(params):
    """Build DynamoDB filter expression from query parameters"""
    filter_parts = []
    expr_values = {}
    expr_names = {}
    
    # Price filters
    if params.get('min_price'):
        filter_parts.append('#price >= :min_price')
        expr_values[':min_price'] = int(params['min_price'])
        expr_names['#price'] = 'price'
    
    if params.get('max_price'):
        filter_parts.append('#price <= :max_price')
        expr_values[':max_price'] = int(params['max_price'])
        expr_names['#price'] = 'price'
    
    if params.get('min_price_per_sqm'):
        filter_parts.append('price_per_sqm >= :min_ppsqm')
        expr_values[':min_ppsqm'] = int(params['min_price_per_sqm'])
    
    if params.get('max_price_per_sqm'):
        filter_parts.append('price_per_sqm <= :max_ppsqm')
        expr_values[':max_ppsqm'] = int(params['max_price_per_sqm'])
    
    # Location filters
    if params.get('ward'):
        filter_parts.append('ward = :ward')
        expr_values[':ward'] = params['ward']
    
    if params.get('district'):
        filter_parts.append('district = :district')
        expr_values[':district'] = params['district']
    
    if params.get('max_station_distance'):
        filter_parts.append('station_distance_minutes <= :max_station')
        expr_values[':max_station'] = int(params['max_station_distance'])
    
    # Property filters
    if params.get('property_type'):
        filter_parts.append('property_type = :prop_type')
        expr_values[':prop_type'] = params['property_type']
    
    if params.get('min_bedrooms'):
        filter_parts.append('num_bedrooms >= :min_br')
        expr_values[':min_br'] = int(params['min_bedrooms'])
    
    if params.get('max_bedrooms'):
        filter_parts.append('num_bedrooms <= :max_br')
        expr_values[':max_br'] = int(params['max_bedrooms'])
    
    if params.get('min_sqm'):
        filter_parts.append('total_sqm >= :min_sqm')
        expr_values[':min_sqm'] = Decimal(params['min_sqm'])
    
    if params.get('max_sqm'):
        filter_parts.append('total_sqm <= :max_sqm')
        expr_values[':max_sqm'] = Decimal(params['max_sqm'])
    
    if params.get('max_building_age'):
        filter_parts.append('building_age_years <= :max_age')
        expr_values[':max_age'] = int(params['max_building_age'])
    
    # Investment filters
    if params.get('verdict'):
        verdicts = params['verdict'].split(',')
        verdict_conditions = []
        for i, verdict in enumerate(verdicts):
            verdict_key = f':verdict{i}'
            verdict_conditions.append(f'verdict = {verdict_key}')
            expr_values[verdict_key] = verdict.upper()
        filter_parts.append(f"({' OR '.join(verdict_conditions)})")
    
    if params.get('min_score'):
        filter_parts.append('investment_score >= :min_score')
        expr_values[':min_score'] = int(params['min_score'])
    
    # Combine all filter parts
    filter_expr = ' AND '.join(filter_parts) if filter_parts else None
    
    return filter_expr, expr_values, expr_names

def get_sort_key(sort_by):
    """Get the sort key and reverse flag based on sort_by parameter"""
    sort_mappings = {
        'price_asc': ('price', False),
        'price_desc': ('price', True),
        'price_per_sqm_asc': ('price_per_sqm', False),
        'price_per_sqm_desc': ('price_per_sqm', True),
        'sqm_asc': ('total_sqm', False),
        'sqm_desc': ('total_sqm', True),
        'age_asc': ('building_age_years', False),
        'age_desc': ('building_age_years', True),
        'station_asc': ('station_distance_minutes', False),
        'station_desc': ('station_distance_minutes', True),
        'score_asc': ('investment_score', False),
        'score_desc': ('investment_score', True),
        'date_asc': ('analysis_date', False),
        'date_desc': ('analysis_date', True),
    }
    
    return sort_mappings.get(sort_by, ('analysis_date', True))

def get_user_favorite_ids(user_id):
    """Get set of property IDs favorited by user"""
    if not user_id or user_id == 'anonymous':
        return set()
    
    try:
        favorites_table_name = os.environ.get('FAVORITES_TABLE')
        if not favorites_table_name:
            return set()
        
        favorites_table = dynamodb.Table(favorites_table_name)
        
        response = favorites_table.query(
            IndexName='user-favorites-index',
            KeyConditionExpression='user_id = :uid',
            ExpressionAttributeValues={':uid': user_id},
            ProjectionExpression='property_id'
        )
        
        return {item['property_id'] for item in response.get('Items', [])}
    except Exception as e:
        print(f"Error getting user favorites: {e}")
        return set()

def lambda_handler(event, context):
    """Handle API requests for property data with cursor-based pagination"""
    
    # Handle OPTIONS request for CORS
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': ''
        }
    
    # Handle default route (404 for unmatched paths) - ensure CORS headers
    route_key = event.get('routeKey', '')
    raw_path = event.get('rawPath', '')
    
    # If this is the $default route (catches all unmatched paths), return 404
    if route_key == '$default':
        return {
            'statusCode': 404,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': 'Not Found'})
        }
    
    # If the path is not exactly /properties, return 404
    if raw_path and raw_path not in ['/properties', '/prod/properties']:
        return {
            'statusCode': 404,
            'headers': CORS_HEADERS,
            'body': json.dumps({'message': 'Not Found'})
        }
    
    try:
        # Get query parameters
        params = event.get('queryStringParameters', {}) or {}
        
        # Get user_id from headers
        user_id = event.get('headers', {}).get('X-User-Id', 'anonymous')
        
        # Pagination parameters
        limit = max(1, min(int(params.get('limit', 100)), 100))  # Default 100, max 100, min 1
        cursor = json.loads(params['cursor']) if 'cursor' in params else None
        
        # Build scan kwargs with projection expression
        scan_kwargs = {
            'Limit': limit,
            'FilterExpression': Attr('sort_key').eq('META'),
            'ProjectionExpression': 'PK, price, size_sqm, total_sqm, ward, ward_discount_pct, img_url, listing_url, #url_attr, verdict, recommendation, property_id, analysis_date, photo_filenames, price_per_sqm, total_monthly_costs, ward_median_price_per_sqm, closest_station, station_distance_minutes, #floor_attr, building_age_years, primary_light',
            'ExpressionAttributeNames': {
                '#url_attr': 'url',
                '#floor_attr': 'floor'
            }
        }
        
        if cursor:
            scan_kwargs['ExclusiveStartKey'] = cursor
        
        # Perform scan
        response = table.scan(**scan_kwargs)
        items = response.get('Items', [])
        last_evaluated_key = response.get('LastEvaluatedKey')
        
        # Get user's favorites if user is authenticated
        user_favorites = get_user_favorite_ids(user_id) if user_id != 'anonymous' else set()
        
        # Format response with necessary transformations
        formatted_items = []
        for item in items:
            # Convert Decimal to float for JSON serialization
            property_data = json.loads(json.dumps(item, default=str))
            
            # Parse numeric strings back to numbers
            numeric_fields = ['price', 'size_sqm', 'total_sqm', 'ward_discount_pct', 'price_per_sqm', 
                            'total_monthly_costs', 'ward_median_price_per_sqm', 'station_distance_minutes', 
                            'floor', 'building_age_years']
            for field in numeric_fields:
                if field in property_data and property_data[field]:
                    try:
                        property_data[field] = float(property_data[field])
                    except:
                        pass
            
            # Fix listing URL field mapping
            if 'url' in property_data and not property_data.get('listing_url'):
                property_data['listing_url'] = property_data['url']
            # If listing_url is still empty, try to reconstruct from property_id
            elif not property_data.get('listing_url') and property_data.get('property_id'):
                prop_id = property_data['property_id']
                if '#' in prop_id and '_' in prop_id:
                    homes_id = prop_id.split('_')[-1]
                    if homes_id.isdigit():
                        property_data['listing_url'] = f"https://www.homes.co.jp/mansion/b-{homes_id}"
            
            # Ensure size_sqm exists (some records might have total_sqm instead)
            if 'total_sqm' in property_data and 'size_sqm' not in property_data:
                property_data['size_sqm'] = property_data['total_sqm']
            
            # Add first image URL if available
            if property_data.get('img_url'):
                property_data['image_url'] = property_data['img_url']
            elif property_data.get('photo_filenames'):
                # Use first photo if available
                first_photo = property_data['photo_filenames'].split('|')[0].strip()
                if first_photo:
                    try:
                        property_data['image_url'] = s3_client.generate_presigned_url(
                            'get_object',
                            Params={'Bucket': s3_bucket, 'Key': first_photo},
                            ExpiresIn=3600
                        )
                    except:
                        pass
            
            # Add favorite status
            property_data['is_favorited'] = property_data.get('property_id') in user_favorites
            
            formatted_items.append(property_data)
        
        # Prepare response
        body = {
            'items': formatted_items,
            'cursor': last_evaluated_key
        }
        
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps(body)
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': str(e)})
        }