import boto3
import json
import time
import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Tuple

class TransitCalculator:
    """
    Calculate transit times from property stations to major Tokyo hubs using Google Maps API.
    Results are cached in DynamoDB to minimize API usage and costs.
    """
    
    # Major Tokyo hubs with coordinates (lat, lng) - Limited to 4 key destinations
    MAJOR_HUBS = {
        'shinjuku': {'name': 'Shinjuku Station', 'coords': (35.6896, 139.7006)},
        'ikebukuro': {'name': 'Ikebukuro Station', 'coords': (35.7295, 139.7109)},
        'ginza': {'name': 'Ginza Station', 'coords': (35.6712, 139.7640)},
        'tokyo': {'name': 'Tokyo Station', 'coords': (35.6812, 139.7671)}
    }
    
    # Cache TTL: 30 days in seconds
    CACHE_TTL_SECONDS = 30 * 24 * 60 * 60
    
    # Rate limiting: 2 requests per second
    REQUEST_DELAY = 0.5
    
    def __init__(self, region_name='ap-northeast-1'):
        self.region_name = region_name
        self.secrets_client = boto3.client('secretsmanager', region_name=region_name)
        self.dynamodb = boto3.resource('dynamodb', region_name=region_name)
        self.logger = logging.getLogger(__name__)
        
        # Initialize cache table
        cache_table_name = self._get_cache_table_name()
        self.cache_table = self.dynamodb.Table(cache_table_name)
        
        # Get Google Maps API key
        self.api_key = self._get_google_maps_api_key()
        
        # Track last request time for rate limiting
        self.last_request_time = 0
    
    def _get_cache_table_name(self) -> str:
        """Get transit cache table name from environment or config"""
        import os
        # Try environment variable first
        table_name = os.getenv('TRANSIT_CACHE_TABLE')
        if table_name:
            return table_name
            
        # Try to load from config
        try:
            import json
            with open('/var/task/config.json', 'r') as f:
                config = json.load(f)
            return config.get('dynamodb', {}).get('DDB_TRANSIT_CACHE', 'tokyo-real-estate-transit-cache')
        except:
            # Fallback to default name
            return 'tokyo-real-estate-transit-cache'
    
    def _get_google_maps_api_key(self) -> str:
        """Retrieve Google Maps API key from AWS Secrets Manager"""
        try:
            # Try to load secret name from config
            try:
                import json
                with open('/var/task/config.json', 'r') as f:
                    config = json.load(f)
                secret_name = config.get('secrets', {}).get('GOOGLE_MAPS_API_KEY', 'tokyo-real-estate/google-maps-api-key')
            except:
                secret_name = 'tokyo-real-estate/google-maps-api-key'
            
            response = self.secrets_client.get_secret_value(SecretId=secret_name)
            
            # Secret could be a simple string or JSON
            secret_string = response['SecretString']
            try:
                secret_dict = json.loads(secret_string)
                return secret_dict.get('api_key', secret_string)
            except json.JSONDecodeError:
                return secret_string
                
        except Exception as e:
            self.logger.error(f"Failed to retrieve Google Maps API key: {e}")
            raise
    
    def _normalize_station_name(self, station_name: str) -> str:
        """Normalize station name for consistent caching and API calls"""
        if not station_name:
            return ""
            
        station_name = station_name.strip()
        
        # Add "駅" (Station) suffix if not present
        if station_name and not station_name.endswith('駅') and not station_name.endswith('Station'):
            station_name += '駅'
            
        return station_name
    
    def _generate_cache_key(self, station_name: str, hub_key: str) -> str:
        """Generate cache key for station-hub pair"""
        normalized_station = self._normalize_station_name(station_name)
        return f"{normalized_station}_{hub_key}_weekday_morning"
    
    def _get_cached_result(self, cache_key: str) -> Optional[int]:
        """Retrieve cached transit time from DynamoDB"""
        try:
            response = self.cache_table.get_item(Key={'cache_key': cache_key})
            
            if 'Item' in response:
                item = response['Item']
                
                # Check if item has expired (extra safety check beyond TTL)
                if 'ttl' in item:
                    ttl_timestamp = int(item['ttl'])
                    current_timestamp = int(time.time())
                    if current_timestamp > ttl_timestamp:
                        return None
                
                # Return cached time in minutes
                return item.get('transit_time_minutes')
                
        except Exception as e:
            self.logger.warning(f"Failed to retrieve cached result for {cache_key}: {e}")
            
        return None
    
    def _cache_result(self, cache_key: str, transit_time_minutes: int) -> None:
        """Store transit time result in DynamoDB cache"""
        try:
            ttl_timestamp = int(time.time()) + self.CACHE_TTL_SECONDS
            
            self.cache_table.put_item(
                Item={
                    'cache_key': cache_key,
                    'transit_time_minutes': transit_time_minutes,
                    'ttl': ttl_timestamp,
                    'created_at': datetime.now(timezone.utc).isoformat()
                }
            )
            
        except Exception as e:
            self.logger.warning(f"Failed to cache result for {cache_key}: {e}")
    
    def _rate_limit(self) -> None:
        """Implement rate limiting for Google Maps API calls"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        if time_since_last_request < self.REQUEST_DELAY:
            sleep_time = self.REQUEST_DELAY - time_since_last_request
            time.sleep(sleep_time)
            
        self.last_request_time = time.time()
    
    def _get_weekday_morning_timestamp(self) -> int:
        """Get timestamp for realistic commute time (current time or next weekday 8:30 AM JST)"""
        now = datetime.now(timezone.utc)
        
        # For testing, use current time + 5 minutes to avoid issues with Google Maps API
        # The API works better with current/recent times rather than future times
        current_timestamp = int(now.timestamp()) + 300  # 5 minutes from now
        return current_timestamp
    
    def _call_google_maps_api(self, station_name: str, hub_coords: Tuple[float, float]) -> Optional[int]:
        """Call Google Maps Directions API to get transit time (with driving fallback)"""
        try:
            self._rate_limit()
            
            normalized_station = self._normalize_station_name(station_name)
            departure_time = self._get_weekday_morning_timestamp()
            
            url = "https://maps.googleapis.com/maps/api/directions/json"
            
            # First try transit mode
            transit_params = {
                'origin': f"{normalized_station}, Tokyo, Japan",
                'destination': f"{hub_coords[0]},{hub_coords[1]}",
                'mode': 'transit',
                'departure_time': departure_time,
                'language': 'en',
                'region': 'jp',
                'key': self.api_key
            }
            
            self.logger.info(f"Trying transit mode: {normalized_station} -> {hub_coords}")
            response = requests.get(url, params=transit_params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            # If transit works, use it
            if data.get('status') == 'OK' and data.get('routes'):
                routes = data.get('routes', [])
                if routes and routes[0].get('legs'):
                    legs = routes[0].get('legs', [])
                    if legs and legs[0].get('duration'):
                        duration_seconds = legs[0]['duration']['value']
                        duration_minutes = round(duration_seconds / 60)
                        self.logger.info(f"✅ Transit time from {normalized_station}: {duration_minutes} minutes")
                        return duration_minutes
            
            # Transit failed, try driving mode as fallback and estimate transit time
            self.logger.info(f"Transit mode failed, trying driving fallback for {normalized_station}")
            
            driving_params = {
                'origin': f"{normalized_station}, Tokyo, Japan", 
                'destination': f"{hub_coords[0]},{hub_coords[1]}",
                'mode': 'driving',
                'language': 'en',
                'region': 'jp',
                'key': self.api_key
            }
            
            response = requests.get(url, params=driving_params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('status') == 'OK' and data.get('routes'):
                routes = data.get('routes', [])
                if routes and routes[0].get('legs'):
                    legs = routes[0].get('legs', [])
                    if legs and legs[0].get('duration'):
                        driving_seconds = legs[0]['duration']['value']
                        driving_minutes = round(driving_seconds / 60)
                        
                        # Estimate transit time as driving time * 2.0 (realistic for Tokyo)
                        # This accounts for transfers, waiting times, walking to/from stations
                        estimated_transit_minutes = round(driving_minutes * 2.0)
                        
                        self.logger.info(f"🚗→🚇 Estimated transit time from {normalized_station}: {estimated_transit_minutes} minutes (from {driving_minutes}min driving)")
                        return estimated_transit_minutes
            
            # Both modes failed
            self.logger.warning(f"Both transit and driving modes failed for {normalized_station} -> {hub_coords}")
            return None
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"HTTP error calling Google Maps API: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Unexpected error calling Google Maps API: {e}")
            return None
    
    def calculate_transit_times(self, station_name: str) -> Dict[str, Optional[int]]:
        """
        Calculate transit times from station to all major hubs.
        
        Args:
            station_name: Name of the origin station (Japanese)
            
        Returns:
            Dictionary with hub keys and transit times in minutes
        """
        if not station_name or not station_name.strip():
            self.logger.warning("Empty station name provided")
            return {hub: None for hub in self.MAJOR_HUBS.keys()}
        
        results = {}
        normalized_station = self._normalize_station_name(station_name)
        
        self.logger.info(f"Calculating transit times from {normalized_station} to major hubs")
        
        for hub_key, hub_info in self.MAJOR_HUBS.items():
            cache_key = self._generate_cache_key(station_name, hub_key)
            
            # Try cache first
            cached_time = self._get_cached_result(cache_key)
            if cached_time is not None:
                self.logger.debug(f"Using cached result for {normalized_station} -> {hub_key}: {cached_time} minutes")
                results[hub_key] = cached_time
                continue
            
            # Call API if not cached
            transit_time = self._call_google_maps_api(normalized_station, hub_info['coords'])
            
            if transit_time is not None:
                # Cache the successful result
                self._cache_result(cache_key, transit_time)
                results[hub_key] = transit_time
            else:
                self.logger.warning(f"Failed to get transit time from {normalized_station} to {hub_key}")
                results[hub_key] = None
        
        return results
    
    def calculate_derived_metrics(self, transit_times: Dict[str, Optional[int]]) -> Dict[str, any]:
        """
        Calculate derived metrics from transit times.
        
        Args:
            transit_times: Dictionary with hub keys and transit times in minutes
            
        Returns:
            Dictionary with derived metrics
        """
        valid_times = [time for time in transit_times.values() if time is not None]
        
        if not valid_times:
            return {
                'min_time_to_major_hub': None,
                'avg_time_to_major_hubs': None,
                'excellent_transit': False
            }
        
        # Calculate minimum time to any major hub
        min_time = min(valid_times)
        
        # Calculate average time to main hubs (Shinjuku, Tokyo, Ginza, Ikebukuro)
        main_hub_times = []
        for hub in ['shinjuku', 'tokyo', 'ginza', 'ikebukuro']:
            if transit_times.get(hub) is not None:
                main_hub_times.append(transit_times[hub])
        
        avg_main_hubs = sum(main_hub_times) / len(main_hub_times) if main_hub_times else None
        
        # Excellent transit: any hub reachable in < 20 minutes
        excellent_transit = min_time < 20
        
        return {
            'min_time_to_major_hub': min_time,
            'avg_time_to_major_hubs': round(avg_main_hubs) if avg_main_hubs else None,
            'excellent_transit': excellent_transit
        }